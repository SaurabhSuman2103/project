import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'componentInteraction';
  id="";
  name="";
  salary="";
  department="";
  add(){
    this.employee.push({empId:this.id,empName:this.name,empSal:this.salary,empDep:this.department})
  }
  ida="";
  namea="";
  salarya="";
  departmenta="";
  a="";
  b="";
  index:any="";
  fill(i)
  {
    this.ida=i.empId;
    this.namea=i.empName;
    this.salarya=i.empName;
    this.departmenta=i.empDep;
    this.index=this.employee.indexOf(i);
  }
  delete(empId)
  {
    for(let i=0;i<this.employee.length;i++)
    {
      if(this.employee[i].empId==empId)
      {
        this.employee.splice(i,1)
      }
    }

  }
  update()
  {
    this.employee.splice(this.index,1,{empId:this.ida,empName:this.namea,empSal:this.salarya,empDep:this.departmenta})
  }
  employee: any[]=
  [
    {empId:1001,empName:"Rahul",empSal:9000,empDep:"Java"},
    {empId:1002,empName:"Sachin",empSal:19000,empDep:"OraApps"},
    {empId:1003,empName:"Vikash",empSal:29000,empDep:"BI"},
    ];

}
