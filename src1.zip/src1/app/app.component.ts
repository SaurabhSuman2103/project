import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'componentInteraction';
  id="";
  name="";
  salary="";
  department="";
  add(){
    alert(this.id+" "+this.name+" "+this.salary+" "+this.department);
  }
}
