import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iemp } from './empl';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpService {

  constructor(private http: HttpClient) { }
  private _url: string = './assets/data/booklist.json'
  getbook(): Observable<Iemp[]> {
    return this.http.get<Iemp[]>(this._url)
  }
}
