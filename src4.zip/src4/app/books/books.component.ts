import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  emp = []
  constructor(private _empployee: EmpService) { }

  ngOnInit() {
    this._empployee.getbook()
      .subscribe(Data => this.emp = Data)

  }

}
